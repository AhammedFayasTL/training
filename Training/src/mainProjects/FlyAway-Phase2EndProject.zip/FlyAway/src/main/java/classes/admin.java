package classes;

import javax.persistence.*;

public class admin {
	private int id;
	@Column
	private String name;
	@Column
	private String password;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public admin(String name, String password, int id) {
		super();
		this.name = name;
		this.password = password;
		this.id = id;
	}

	public admin() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
}
