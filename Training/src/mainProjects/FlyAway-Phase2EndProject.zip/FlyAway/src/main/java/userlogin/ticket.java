package userlogin;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import classes.*;
import util.HibernateSessionUtil;

@WebServlet("/ticket")
public class ticket extends HttpServlet{

	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		HttpSession ss=request.getSession(false);
		if(ss!=null) {
		
		try {
			// 1. build hibernate session factory
			SessionFactory factory = HibernateSessionUtil.buildSessionFactory();
			
			// 2. create session object
			Session session = factory.openSession();
			
			// 3. read products
			@SuppressWarnings("unchecked")
			List<user> obj = session.createQuery("from user").list();
			String n="";
			@SuppressWarnings("unused")
			int flag=0;
			for(user p : obj) {
				if(ss.getAttribute("usersid").equals(p.getId())) {
					n=p.getName();
				}
			}
			out.print("<html><body>");
			out.print("<center><h1 style=\"color:green\">TICKET CONFIRMED</h1>"
					+ "</center>\n"+ "  <div style=\"padding: 2px 16px;\">\n");
			
			out.print("<center><h4><b> BOOKED BY - "+n+"</b></h4> \n" + 
			"<h4><b> BOOKING ID - "+ss.getAttribute("usersid")+"</b></h4>"+
			"<h4><b> AIRLINES - "+ss.getAttribute("flightname")+"</b></h4>"+
					"<h4 style='color:green;'><b> From - "+ss.getAttribute("sourceplace")+" ||  To - "+ss.getAttribute("destinationplace")+"</b></h4>"+
					"    <p>Thank you for choosing us!</p> </center>\n" + 
					"  </div>\n" + 
					"</div>\n" + 
					"</center>");
			out.print("</body></html>");
			session.close();
		} catch (Exception e) {
			out.print("<h3 style='color:red'> Hibernate session is failed ! "+e+"</h3>");
		}
		}
	}
}