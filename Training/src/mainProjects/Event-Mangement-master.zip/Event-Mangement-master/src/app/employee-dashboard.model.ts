export class EmployeeModel {
  id: number = 0;
  firstName: string = '';
  LastName: string = '';
  email: string = '';
}
