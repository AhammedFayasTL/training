package com.dao;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import com.bean.User;

public class UserDao {
	JdbcTemplate template;

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}

	public int insert(User usr) {
		String sql = "insert into User(id,name,age)values(?,?,?)";
		int ans = template.update(sql, usr.getId(), usr.getName(), usr.getAge());
		return ans;
	}

	public int update(User usr) {
		String sql = "update User set name=?, age=? where id=?";
		int ans = template.update(sql, usr.getName(), usr.getAge(), usr.getId());
		return ans;
	}

	public int delete(int id) {
		String sql = "delete from User where id=?";
		return template.update(sql, id);
	}

	public User getUid(int id) {
		String sql = "select * from User where id=?";

		User usr = template.queryForObject(sql, new Object[] { id }, new UserMapper());
		return usr;
	}

	public List<User> getUserDetails() {
		String sql = "select * from User";
		List<User> usrList = template.query(sql, new UserMapper());
		return usrList;
	}

}
