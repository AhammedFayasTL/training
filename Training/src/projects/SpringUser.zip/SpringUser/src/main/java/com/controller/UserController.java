package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.bean.User;
import com.dao.UserDao;

@Controller
public class UserController {
	@Autowired
	UserDao dao;

	@RequestMapping(value = "/usrform", method = RequestMethod.GET)
	public String showForm(Model m) {
		m.addAttribute("usr", new User());
		return "usrform";

	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String save(@ModelAttribute("usr") User usr) {
		dao.insert(usr);
		return "redirect:/viewusr";
	}

	@RequestMapping("/viewusr")
	public String viewusr(Model m) {
		List<User> usrList = dao.getUserDetails();
		/*
		 * for(Employee e : empList){ System.out.println(e.getEid()); }
		 */
		m.addAttribute("usrList", usrList);
		return "viewusr";
	}

	@RequestMapping(value = "/editusr/{id}")
	public String edit(@PathVariable int id, Model m) {

		User usr = dao.getUid(id);
		m.addAttribute("usr", usr);
		return "usreditform";
	}

	@RequestMapping(value = "/editsave", method = RequestMethod.POST)
	public String editSave(@ModelAttribute("usr") User usr) {

		// System.out.println(usr.getEid());
		dao.update(usr);
		return "redirect:/viewusr";
	}

	@RequestMapping(value = "/deleteusr/{id}")
	public String delete(@PathVariable int id) {
		dao.delete(id);
		return "redirect:/viewusr";
	}

}
