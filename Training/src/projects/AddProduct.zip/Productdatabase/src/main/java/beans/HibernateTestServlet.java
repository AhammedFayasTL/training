package beans;

import java.io.IOException;

import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import org.hibernate.cfg.Configuration;

@WebServlet("/HibernateTestServlet")
public class HibernateTestServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	int register(product user) {
		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		int i = (Integer) session.save(user);
		session.getTransaction().commit();

		session.close();
		return i;

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String pname = request.getParameter("txtname");
		int quantity = Integer.parseInt(request.getParameter("txtqty"));
		int price = Integer.parseInt(request.getParameter("txtprice"));
		// put values in Object
		product pro = new product();
		pro.setName(pname);
		pro.setQuantity(quantity);
		pro.setPrice(price);

		int i = register(pro);
		PrintWriter out = response.getWriter();
		if (i > 0)
			out.println("Record Inserted");
		else
			out.println("Record not Inserted");
	}

}