package com.h2;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import java.util.List;
import org.junit.jupiter.api.DisplayName;


class UserServiceTest{

	@Test
	@DisplayName("Check User Details Testing")
	void testCheckUser() {
		//fail("Not yet implemented");
		UserService us = new UserService();
		String result = us.checkUser("fayas@gmail.com", "1234");
		assertEquals("success", result);
		
		String result1 = us.checkUser("faya@gmail.com", "123");
		assertEquals("failure", result1);
	}

	@Test
	@DisplayName("User not null Testing")
	void testGetUser() {
		//fail("Not yet implemented");
		UserService us = new UserService();
		User usr = us.getUser();
		assertNotNull(usr);
		assertEquals("shinu@gmail.com", usr.getUsername());
		assertEquals("1234", usr.getPassword());
	}

	@Test
	@DisplayName("Check Username not null Testing")
	void testGetName() {
		//fail("Not yet implemented");
		UserService us = new UserService();
		User usr = us.getName();
		assertNotNull(usr);
	}

	@Test
	@DisplayName("Check Password not null Testing")
	void testGetPassword() {
		//fail("Not yet implemented");
		UserService us = new UserService();
		User usr = us.getpassword();
		assertNotNull(usr);
	}

	@Test
	@DisplayName("Get All User Testing")
	void testGetAllUser() {
		//fail("Not yet implemented");
		UserService us = new UserService();
		List<User> list = us.getAllUser();
	}

}