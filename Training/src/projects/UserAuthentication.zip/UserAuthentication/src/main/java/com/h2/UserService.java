package com.h2;

import java.util.ArrayList;
import java.util.List;


public class UserService {
	
	public String checkUser(String emailid, String password) {
		if(emailid.equals("fayas@gmail.com") && password.equals("1234")) {
			return "success";
		}
		else {
			return "failure";
		}
	}
	
	public User getUser() {
		User usr = new User();
		usr.setUsername("shinu@gmail.com");
		usr.setPassword("1234");
		return usr;
	}
	
	public User getName() {
		User usr = new User();
		usr.setUsername("shinu@gmail.com");
		return usr;
	}
	
	public User getpassword() {
		User usr = new User();
		usr.setPassword("1234");
		return usr;
	}
	
	public List<User> getAllUser(){
		List<User> list = new ArrayList<User>();
		User usr = new User();
		usr.setUsername("sharath@gmail.com");
		usr.setPassword("3456");
		usr.setUsername("adarsh@gmail.com");
		usr.setPassword("5678");
		usr.setUsername("piya@gmail.com");
		usr.setPassword("1256");
		return list;		
	}

}
