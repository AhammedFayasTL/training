package com.seleniumautomate;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Login {
	public static void main(String[] args) throws InterruptedException
    {
        System.setProperty(
            "webdriver.chrome.driver",
            "C:\\Users\\Ahammed Fayas T L\\Desktop\\simplielearn-java\\Simplielearn/chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        
        driver.get("https://www.facebook.com/login/?privacy_mutation_token=eyJ0eXBlIjowLCJjcmVhdGlvbl90aW1lIjoxNjY0MzY3NDQ2LCJjYWxsc2l0ZV9pZCI6MjY5NTQ4NDUzMDcyMDk1MX0%3D");
        
        driver.manage().window().maximize();
		 
        
        
        driver.findElement(By.id("email"))
        .sendKeys("fayas@gmail.com");
        
        driver.findElement(By.id("pass"))
        .sendKeys("abcdefg@123");
        
        driver.findElement(By.id("loginbutton"))
        .click();
        
    }
}
