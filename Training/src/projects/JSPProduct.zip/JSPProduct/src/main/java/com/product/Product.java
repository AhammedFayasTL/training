package com.product;

public class Product {
  private int pid;
  private String pname;
  private int quantity;
  private int price;
  
  public int getId() {
	  return pid;
  }
  public void setId(int pid){ 
	  this.pid=pid;
  }
  public String getName() {
	  return pname;
  }
  public void setName(String pname) {
	  this.pname=pname;
  }
  public int getQuantity() {
	  return quantity;
  }
  public void setQuantity(int quantity) {
	  this.quantity = quantity;
  }
  public int getPrice() {
	  return price;
  }
  public void setPrice(int price) {
	  this.price=price;
  }
  @Override
	public String toString() {
		return "Product [ProductID " + pid + ", ProductName " +  pname +", Productquantity " +  quantity + ", ProductPrice " + price + "]";
	}
}
