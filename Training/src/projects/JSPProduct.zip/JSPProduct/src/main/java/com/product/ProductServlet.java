package com.product;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ProductServlet
 */
@WebServlet("/ProductServlet")
public class ProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ProductServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int pid = Integer.parseInt(request.getParameter("txtid"));
		String pname = request.getParameter("txtname");
		int quantity = Integer.parseInt(request.getParameter("txtqty"));
		int price = Integer.parseInt(request.getParameter("txtprice"));
		Product p = new Product();
		p.setId(pid);
		p.setName(pname);
		p.setQuantity(quantity);
		p.setPrice(price);

		HttpSession ss = request.getSession();
		request.getSession(true);
		Object obj = ss.getAttribute("obj");
		List<Product> listOfObj;
		if (obj == null) {
			listOfObj = new ArrayList<Product>();
			listOfObj.add(p);
			ss.setAttribute("obj", listOfObj);
		} else {
			listOfObj = (List<Product>) ss.getAttribute("obj");
			listOfObj.add(p);
			ss.setAttribute("obj", listOfObj);
		}
		response.sendRedirect("display.jsp");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
