package com.rest;

import javax.servlet.http.HttpServletRequest;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FeedbackController {

	@Autowired
	FeedbackService feedbackService;
	
	// To take input as json use this method
	/*@RequestMapping(value = "feedback" ,consumes = MediaType.APPLICATION_JSON_VALUE, method=RequestMethod.POST)
	public String storeFeedBackdb(@RequestBody Feedback fd)
	{
		
		return feedbackService.storeFeedback(fd);
		
	}*/
	
	@RequestMapping(value = "/feedback" ,consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE, method=RequestMethod.POST,produces = MediaType.TEXT_HTML_VALUE)
	public String storeFeedBackdb(HttpServletRequest req,Feedback fd)
	{
		int id=Integer.parseInt(req.getParameter("fid"));
		String name=req.getParameter("name");
		String feedback=req.getParameter("feedback");
		
		fd.setFid(id);
		fd.setName(name);
		fd.setFeedback(feedback);
		
		return feedbackService.storeFeedback(fd);
		
	}
	
	
	
	
}
