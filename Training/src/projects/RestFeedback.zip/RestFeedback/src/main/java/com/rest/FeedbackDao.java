package com.rest;

import javax.persistence.EntityManager;

import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


@Repository
public class FeedbackDao {
	
	@Autowired
	EntityManagerFactory emf;

	
	public int storeFeedback(Feedback fd)
	{
		try {
		EntityManager manager=emf.createEntityManager();
		EntityTransaction tran=manager.getTransaction();
		tran.begin();
		  manager.persist(fd);
		tran.commit();
		return 1;
		}catch (Exception e) {
			System.out.println(e);
			return 0;
		}		
		
	}
}
