package com.rest;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Feedback {
@Id
private int fid;
private String name;
private String feedback;



public Feedback() {
	super();
	// TODO Auto-generated constructor stub
}

public Feedback(int fid, String name, String feedback) {
	super();
	this.fid = fid;
	this.name = name;
	this.feedback = feedback;
}

public int getFid() {
	return fid;
}

public void setFid(int fid) {
	this.fid = fid;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getFeedback() {
	return feedback;
}

public void setFeedback(String feedback) {
	this.feedback = feedback;
}

@Override
public String toString() {
	return "Feedback [fid=" + fid + ", name=" + name + ", feedback=" + feedback + "]";
}




}