package com.rest;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;


@Service
public class FeedbackService {
	
	@Autowired
    FeedbackDao feedbackDao;
	
	public String storeFeedback(Feedback fd)
	{
		if(feedbackDao.storeFeedback(fd)>0)
		{
			return "<h4>Feedback Successfully Stored! <br> Thank You for your Response<h4></br> <a href='index.html'>Go Back</a>";
		}
		else
		{
			return "<h4>Feedback Didn't Store<h4></br> <a href='index.html'>Go Back</a>";
		}
	}

}
